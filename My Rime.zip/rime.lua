function time_translator(input, seg)
   if (input == "date") then
      local cand = Candidate("date", seg.start, seg._end, os.date("%Y%m%d"), "")
      cand.quality = 1000
      yield(cand)
   end
   if (input == "time") then
      local cand = Candidate("time", seg.start, seg._end, os.date("%H%M%S"), " ")
      cand.quality = 1000
      yield(cand)
   end
   if (input == "dtdt") then
      local cand = Candidate("time", seg.start, seg._end, os.date("%Y%m%d_%H%M%S"), " ")
      cand.quality = 3000
      yield(cand)
   end
end